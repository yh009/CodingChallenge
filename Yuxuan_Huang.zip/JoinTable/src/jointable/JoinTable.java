/*
 * Coding Challenge for Veeva
 *
 * Assumptions:
 * 1. "id" is the unique key in Name.csv, even if more columns were to be added
 * 2. The position of the columns in the two tables remain
 * unchanged. More columns would to be added after "name" in Name.csv.
 *
 * Dependency:
 * 1. com.opencsv.CSVReader
 *
 * Name: Yuxuan Huang
 * Date: June 27, 2020
 *
 */
package jointable;

import com.opencsv.*;
import java.io.*;
import java.util.*;

/*
 List of tasks to be performed:
   1. Read data from Name.csv
   2. Construct HashMap for each column in Name.csv, using "id" as key
   3. Read data from Phone.csv, search the HashMap for "name_id" as key.
   4. Construct ArrayList for matching data, append "phone"

   @author: Yuxuan Huang
 */
public class JoinTable {

    private static List<String> header;
    private static HashMap<String, List> Result = new HashMap<String, List>();
    private static Integer maxPhoneNum = 0;
    private static Integer colNumName = 0;

    /**
     * *****************************************
     *
     * Q1
     */
    /*
        buildNameHash method takes the "Name.csv" and convert into a HashMap Result,
        using "id" as the key and the whole row(including "id") as value
     */
    private static void buildNameHashQ1(String file) {

        try {
            // Create an object of filereader
            // class with CSV file as a parameter.
            FileReader filereader = new FileReader(file);

            // create csvReader object passing
            // file reader as a parameter
            CSVReader csvReader = new CSVReader(filereader);
            String[] headerTmp;
            headerTmp = csvReader.readNext();
            header = new ArrayList<>(Arrays.asList(headerTmp)); // Store the header
            colNumName = header.size();

            String[] nextRecord;
            List<String> tmp;

            // read data line by line and build HashMap
            while ((nextRecord = csvReader.readNext()) != null) {
                tmp = new ArrayList<>(Arrays.asList(nextRecord));
                Result.put(nextRecord[0], tmp);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /*
        buildPhoneHash takes the "Phone.csv" line by line and append phone number
        to the value of HashMap Result if "name_id" found in the HashMap.
        At the same time, it keeps track of maximum number of phone numbers for an individual
        for the purpose of building header in the output later.

     */
    private static void buildPhoneHashQ1(String file) {
        try {
            // Create an object of filereader
            // class with CSV file as a parameter.
            FileReader filereader = new FileReader(file);

            // create csvReader object passing
            // file reader as a parameter
            CSVReader csvReader = new CSVReader(filereader);
            csvReader.skip(1);// Skip header

            String[] nextRecord;
            List<String> tmp;

            // read data line by line and add phone to HashMap values
            while ((nextRecord = csvReader.readNext()) != null) {
                if (Result.containsKey(nextRecord[2])) {
                    tmp = Result.get(nextRecord[2]);
                    tmp.add(nextRecord[1]);
                    Result.replace(nextRecord[2], tmp);
                    if ((tmp.size() - colNumName) > maxPhoneNum) {
                        maxPhoneNum = tmp.size() - colNumName;
                    }
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

    }

    private static void writeToCsvQ1(String outputFilePath) {
        // first create file object for file placed at location
        // specified by filepath
        File file = new File(outputFilePath);
        try {
            // create FileWriter object with file as parameter
            FileWriter outputfile = new FileWriter(file);

            // create CSVWriter object filewriter object as parameter
            CSVWriter writer = new CSVWriter(outputfile,
                                             CSVWriter.DEFAULT_SEPARATOR,
                                             CSVWriter.DEFAULT_QUOTE_CHARACTER,
                                             CSVWriter.DEFAULT_ESCAPE_CHARACTER,
                                             CSVWriter.DEFAULT_LINE_END);

            // adding header to csv
            for (int i = 1; i <= maxPhoneNum; i++) {
                header.add("Phone_" + i);
            }
            String[] finalHeader = header.toArray(new String[0]); //Convert List back to Array....
            writer.writeNext(finalHeader);

            // add data to csv, skip record with no phone number
            for (HashMap.Entry mapEle : Result.entrySet()) {
                List<String> tmpRow = (List<String>) mapEle.getValue();
                if (tmpRow.size() < colNumName + 1) {
                    continue; //Skipping record with no phone number
                }
                else {
                    if (tmpRow.size() < maxPhoneNum + colNumName) {
                        for (int j = 0; j < maxPhoneNum + colNumName - tmpRow.size(); j++) {
                            tmpRow.add("");//Add space holder
                        }
                    }
                    String[] resRow = tmpRow.toArray(new String[0]);
                    writer.writeNext(resRow);
                }
            }

            // closing writer connection
            writer.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    /**
     * **************************************************************************
     * Q2: We want to prioritize memory saving over performance
     *
     * I'm sure there are better ways to optimize the use of memory, but the
     * simple idea here is instead of storing everything in the HashMap, we only
     * store the data from Phone.csv into HashMap. The whole Output table would
     * be "joined" upon reading the Name.csv line by line. This way, we can free
     * up some memory spaced used to store data from Name.csv compared with the
     * previous solution(Q1). Considering Name.csv could expend not only in
     * number of rows but also number of columns, such seemingly marginal
     * improvement could potentially save a lot of memory without actual
     * compromising runtime performance.
     *
     */
    private static void buildPhoneHashQ2(String file) {
        try {
            // Create an object of filereader
            // class with CSV file as a parameter.
            FileReader filereader = new FileReader(file);

            // create csvReader object passing
            // file reader as a parameter
            CSVReader csvReader = new CSVReader(filereader);
            csvReader.skip(1);// Skip header

            String[] nextRecord;
            List<String> tmp;

            // read data line by line and build HashMap
            while ((nextRecord = csvReader.readNext()) != null) {
                if (Result.containsKey(nextRecord[2])) {
                    tmp = Result.get(nextRecord[2]);
                    tmp.add(nextRecord[1]);
                    Result.replace(nextRecord[2], tmp);
                    if ((tmp.size()) > maxPhoneNum) {
                        maxPhoneNum = tmp.size();
                    }
                }
                else {
                    tmp = new ArrayList<>(Arrays.asList(nextRecord[1]));
                    Result.put(nextRecord[2], tmp);
                    if (maxPhoneNum < 1) {
                        maxPhoneNum = 1;
                    }
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private static void writeToCsvQ2(String Name, String outputFilePath) {
        File file = new File(outputFilePath);
        try {
            // Create an object of filereader
            // class with CSV file as a parameter.
            FileReader filereader = new FileReader(Name);

            // create csvReader object passing
            // file reader as a parameter
            CSVReader csvReader = new CSVReader(filereader);

            // create FileWriter object with file as parameter
            FileWriter outputfile = new FileWriter(file);

            // create CSVWriter object filewriter object as parameter
            CSVWriter writer = new CSVWriter(outputfile,
                                             CSVWriter.DEFAULT_SEPARATOR,
                                             CSVWriter.DEFAULT_QUOTE_CHARACTER,
                                             CSVWriter.DEFAULT_ESCAPE_CHARACTER,
                                             CSVWriter.DEFAULT_LINE_END);

            String[] headerTmp;
            headerTmp = csvReader.readNext();
            header = new ArrayList<>(Arrays.asList(headerTmp)); // Store the header
            colNumName = header.size();

            // adding header to csv
            for (int i = 1; i <= maxPhoneNum; i++) {
                header.add("Phone_" + i);
            }
            String[] finalHeader = header.toArray(new String[0]); //Convert List back to Array....
            writer.writeNext(finalHeader);

            String[] nextRecord;
            List<String> tmpRow;

            // read data line by line and build HashMap
            while ((nextRecord = csvReader.readNext()) != null) {
                if (Result.containsKey(nextRecord[0])) {
                    tmpRow = new ArrayList<>(Arrays.asList(nextRecord));
                    tmpRow.addAll(Result.get(nextRecord[0]));
                    if (tmpRow.size() < colNumName + maxPhoneNum) {
                        for (int j = 0; j < maxPhoneNum + colNumName - tmpRow.size(); j++) {
                            tmpRow.add("");//Add space holder
                        }
                    }
                    String[] resRow = tmpRow.toArray(new String[0]);
                    writer.writeNext(resRow);
                }
            }
            // closing writer connection
            writer.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /* Just to clean up class level variables */
    private static void clearVariables() {
        Result.clear();
        header.clear();
        maxPhoneNum = 0;
        colNumName = 0;
    }

    /*
        The main method which runs both Q1 and Q2

     */
    public static void main(String[] args) {

        // Q1
        buildNameHashQ1(System.getProperty("user.dir") + "/data/Name.csv");
        buildPhoneHashQ1(System.getProperty("user.dir") + "/data/Phone.csv");
        writeToCsvQ1(System.getProperty("user.dir") + "/data/Output1.csv");

        // Q2
        clearVariables();
        buildPhoneHashQ2(System.getProperty("user.dir") + "/data/Phone.csv");
        writeToCsvQ2(System.getProperty("user.dir") + "/data/Name.csv",
                     System.getProperty("user.dir") + "/data/Output2.csv");

    }

}
